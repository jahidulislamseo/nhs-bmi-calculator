import app from '../server/index';

export default app;
